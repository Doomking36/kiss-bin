#include <alsa/sound/uapi/sb16_csp.h>
#ifndef __sb16_csp_type_defined
#define __sb16_csp_type_defined
typedef struct snd_sb_csp_microcode snd_sb_csp_microcode_t;
#endif
